const mainContent = document.getElementById('main-content');
const courseList = document.getElementById('course-list');
