# Fancy-Buttons

I created Neon button hover effect using transitions property in in CSS.
#
<img src="https://github.com/Khushi260/Web-Development/blob/master/Fancy-Buttons/images/Green.png">

<img src="https://github.com/Khushi260/Web-Development/blob/master/Fancy-Buttons/images/pink.png">

<img src="https://github.com/Khushi260/Web-Development/blob/master/Fancy-Buttons/images/blue.png">
