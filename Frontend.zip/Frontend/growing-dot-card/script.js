for (let i = 0; i < 100; i++) {
const gridEffectTile = document.createElement("a");
gridEffectTile.setAttribute("class", "card__grid-effect-tile");
gridEffectTile.setAttribute("href", "#");
document.querySelector(".card__grid-effect").appendChild(gridEffectTile);
}
            
