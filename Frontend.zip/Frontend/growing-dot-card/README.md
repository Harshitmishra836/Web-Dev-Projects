<div align="center">

# website preloader animation

Hey there! We've got an awesome website preloader animation just for you. It's super cool and will make your website look even more amazing. Check it out now!

 <a href="https://tomsabu444.github.io/FrontEnd-DEV/growing-dot-card/"><strong>➥ Live Demo</strong></a> 
 
 </div>
 
## Demo   <a href="https://tomsabu444.github.io/FrontEnd-DEV/growing-dot-card/"><strong>➥ Live Demo</strong></a> 



<div align="center">

# License

This project is **free to use** and does not contains any license.
 </div>